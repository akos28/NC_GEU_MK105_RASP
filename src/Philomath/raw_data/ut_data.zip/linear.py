import os
from glob import glob

import pandas as pd

import numpy as np

path = 'dat/'
ext = 'csv'

ext = "".join(["[{}]".format(ch + ch.swapcase()) for ch in ext])
files = glob(os.path.join(path, "*." + ext))


for file in files:
	df = pd.read_csv(file, header=0)
	if df.shape[0] > 2:
		if df[file[4:-4]].dtype == object:
			for i in range(len(df[file[4:-4]])):
				df[file[4:-4]][i] = float(df[file[4:-4]][i].replace(" ", ""))
			save = df[file[4:-4]]
		else:
			save = df[file[4:-4]]

		save = np.asarray(save, dtype='float')
		year = np.asarray(df['year'], dtype='float')
		mymodel = np.poly1d(np.polyfit(year, save, 3))

		rang = np.arange(2000, 2031).reshape(-1, 1)
		y_pred = mymodel(rang)

		np.savetxt(file[4:], np.concatenate((rang, y_pred), axis=1), fmt='%d, %.2f', delimiter=',')