import csv
import uuid
from elasticsearch import Elasticsearch
import json

es = Elasticsearch(hosts=[{'host': '139.59.57.160', 'port': 9200}])

for i in range(57, 77):
	print('Pushing {}.json data...'.format(i))
	fname = '{}.json'.format(i)
	with open(fname) as f:
		data = json.load(f)

	data = data[2:]

	for li in data:
		for val in li:
			#val["job-title"]
			#val["company"]
			val["date posted"] = " ".join(val["location"].split())
			val["location"] = " ".join(val["location"].split())
			#val["duration"] = " ".join(val["duration"].split())
			#val["salary"] = " ".join(val["salary"].split())
			#val["description"] = " ".join(val["description"].split())
			val["skills"] = " ".join(val["skills"].split())[9:]

			es.create(index='monster', id=uuid.uuid4(), doc_type="posting", refresh=True, body=val)


# with open('TwitterOutput.csv') as csv_file:
#     csv_reader = csv.reader(csv_file, delimiter=',')
#     line_count = 0
#     for row in csv_reader:
#         es.create(index="twitter", id=uuid.uuid4(), doc_type="posting", refresh=True, body={"content": row[-1]})

# print(es.indices.delete(index='test2', ignore=[400, 404]))

# print(es.indices.create('twitter'))
# print(es.indices.create('monster'))
# print(es.indices.create('indeed'))


#es.create(index="twitter", id="1", doc_type="articles", refresh=True, body={"content": "One more fox"})

# res = es.search(index="test2", doc_type="articles", body={"query": {"match": {"content": "fox"}}})

# print("%d documents found" % res['hits']['total']['value'])

# for doc in res['hits']['hits']:
#     print("%s) %s" % (doc['_id'], doc['_source']['content']))

# res = es.search(index="monster", doc_type="posting", body={"query": {"match": {"job-title": "Software"}}})
# print("%d documents found" % res['hits']['total']['value'])
# for doc in res['hits']['hits']:
#     print("(%s) %s" % (doc['_id'], doc['_source']['location']))

# es = Elasticsearch(hosts=[{'host': '134.209.145.239', 'port': 9200}])
# print(es.search(index="twitter", doc_type="posting", body={"query": {"match": {"a":"hello"}}}))

# print(es.delete(index="twitter", id='96f2b325-5779-4d61-bdf8-94392f334c03'))